# raspberry-pi-tensorflow

This is a repository from the article https://towardsdatascience.com/object-detection-with-tensorflow-model-and-opencv-d839f3e42849
